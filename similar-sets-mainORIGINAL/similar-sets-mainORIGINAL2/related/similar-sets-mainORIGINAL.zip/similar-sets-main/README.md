# similar-sets
An index data struture for storing and querying sets of sets.
